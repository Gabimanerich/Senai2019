import {VpAppConfig}  from './config';

export {VpAppConfig};