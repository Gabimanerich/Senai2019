import Get from './get';
import Post from './post';
import Patch from './patch';
import Put from './put';

export {Get};
export {Post};
export {Patch};
export {Put};